import UIKit

var a: Any = 123
//var a = 123 as Any
a = 456
a = 456.789
a = "Hello"

//a.count

//Type Check -  is operator
//Val(expr) is Type
a is Int
a is String

//Type Casting
//1) Compile Type Casting : as
let str = "Hello" //Swift String, struct
let nsstr: NSString = "Hello" //Foundation String, class

//Some Swift and Foundation Types are bridged.
//String <-> NSString
//Array <-> NSArray
//Date <-> NSDate

let nsstrFromStr: NSString = str as NSString
let strFromNSstr: String = nsstr as String

//2) Runtime Type Casting
//a) Forced Type Casting : as!
//let strFromNSstr1: String = a as! String

//b) Conditional Type Casting : as?
let strFromNSstr2: String? = a as? String
//a.count
if let a = a as? String{
    a.count
}

// upcasting & downcasting
class A {
    let one = "one"
}

class B: A {
    let two = "two"
}

class C: B {
    let three = "three"
}

let aObj = A()
aObj.one
//aObj.two
//aObj.three
let bObj = B()
bObj.one
//bObj.two
//bObj.three
let cObj = C()
cObj.one
cObj.two
//cObj.three

let valueList: [Any] = [1,2,"3"]
//let valueList: [Any] = [1,2,"3"] as [Any]
valueList[0]
//valueList[2].count
if let str = valueList[2] as? String{
    str.count
}

let objList: [A] = [aObj, bObj, cObj]
objList[0] //objList.first
objList[2] //objList.last

if let lastObj = objList.last as? C { //downcasting
    lastObj.three
}

//AnyObject can represent an instance of any class type

struct D{}

let anyObj: AnyObject = A()
let anyObj2 = D()

class Vehicle { }
class Car: Vehicle {
    let brand = "Tesla"
}

let myVehicle: Vehicle = Car()

if let car = myVehicle as? Car{
    car.brand
}
